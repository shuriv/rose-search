# Rose Search Engine - Installation Guide

## Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```

3. **Open in Browser**
   ```
   http://localhost:3000
   ```

## Features
- 🌹 Beautiful rose-themed design
- 🔍 Web search and AI image generation
- 🎨 6 themes + 15 backgrounds
- ⚙️ Extensive customization options
- 📱 Fully responsive design

## Need Help?
Read the full README.md file for detailed instructions.

Enjoy your beautiful search engine! 🌹
